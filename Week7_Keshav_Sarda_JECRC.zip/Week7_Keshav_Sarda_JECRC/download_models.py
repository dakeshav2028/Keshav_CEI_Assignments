import sys
from transformers import AutoTokenizer, AutoModel, AutoModelForSeq2SeqLM

EMBEDDING_MODEL_NAME = 'sentence-transformers/all-MiniLM-L6-v2'
LLM_MODEL_NAME = 'google/flan-t5-small'

try:
    print("Pre-downloading and caching embedding model...")
    AutoTokenizer.from_pretrained(EMBEDDING_MODEL_NAME)
    AutoModel.from_pretrained(EMBEDDING_MODEL_NAME)
    
    print("Pre-caching models completed successfully!")
except Exception as e:
    print(f"Error caching models: {e}", file=sys.stderr)
    sys.exit(1)
