import os
import pickle
import tempfile
import requests
import numpy as np
import docx
import pypdf
import torch
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from transformers import AutoTokenizer, AutoModel, AutoModelForSeq2SeqLM
from langchain_text_splitters import RecursiveCharacterTextSplitter
from dotenv import load_dotenv

# Load environment variables
TEMPLATE_DIR = os.path.dirname(os.path.abspath(__file__))
dotenv_path = os.path.join(os.path.dirname(TEMPLATE_DIR), '.env')
if os.path.exists(dotenv_path):
    load_dotenv(dotenv_path)
else:
    load_dotenv()

GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "").strip()
if not GROQ_API_KEY:
    GROQ_API_KEY = "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"

# Flask initialization
app = Flask(__name__, template_folder=TEMPLATE_DIR)
CORS(app)

# Paths
WORKSPACE_DIR = os.environ.get('WORKSPACE_DIR', TEMPLATE_DIR)
INDEX_PATH = os.path.join(WORKSPACE_DIR, 'rag_index.pkl')

# Global system variables
EMBEDDING_MODEL_NAME = 'sentence-transformers/all-MiniLM-L6-v2'
LLM_MODEL_NAME = 'google/flan-t5-small'

# Initialize models globally (with lazy loading)
embedding_tokenizer = None
embedding_model = None
local_llm_tokenizer = None
local_llm_model = None

def get_embedding_model():
    global embedding_tokenizer, embedding_model
    if embedding_tokenizer is None or embedding_model is None:
        print("Loading embedding model...")
        embedding_tokenizer = AutoTokenizer.from_pretrained(EMBEDDING_MODEL_NAME)
        embedding_model = AutoModel.from_pretrained(EMBEDDING_MODEL_NAME)
        embedding_model.eval()
    return embedding_tokenizer, embedding_model

def get_local_llm():
    global local_llm_tokenizer, local_llm_model
    if local_llm_tokenizer is None or local_llm_model is None:
        print("Loading local LLM...")
        local_llm_tokenizer = AutoTokenizer.from_pretrained(LLM_MODEL_NAME)
        local_llm_model = AutoModelForSeq2SeqLM.from_pretrained(LLM_MODEL_NAME)
    return local_llm_tokenizer, local_llm_model

# ----------------- RAG Components -----------------

class SimpleVectorStore:
    def __init__(self):
        self.chunks = []
        self.embeddings = []
        self.filenames = []

    def add_documents(self, chunks, embeddings, filename):
        self.chunks.extend(chunks)
        self.filenames.extend([filename] * len(chunks))
        if len(self.embeddings) == 0:
            self.embeddings = embeddings
        else:
            self.embeddings = np.vstack([self.embeddings, embeddings])

    def similarity_search(self, query_embedding, k=3):
        if len(self.chunks) == 0:
            return []
        similarities = np.dot(self.embeddings, query_embedding)
        top_indices = np.argsort(similarities)[::-1][:k]
        
        results = []
        for idx in top_indices:
            results.append({
                'chunk': self.chunks[idx],
                'filename': self.filenames[idx],
                'score': float(similarities[idx])
            })
        return results

    def clear(self):
        self.chunks = []
        self.embeddings = []
        self.filenames = []


# Load or initialize vector store
vector_store = SimpleVectorStore()
if os.path.exists(INDEX_PATH):
    try:
        with open(INDEX_PATH, 'rb') as f:
            vector_store = pickle.load(f)
        print(f"Loaded existing index with {len(vector_store.chunks)} chunks.")
    except Exception as e:
        print(f"Error loading index: {e}, initializing fresh vector store.")


# ----------------- Document Processing -----------------

def extract_text_from_file(file_path):
    ext = os.path.splitext(file_path)[1].lower()
    if ext == '.docx':
        doc = docx.Document(file_path)
        return "\n".join([p.text for p in doc.paragraphs])
    elif ext == '.pdf':
        reader = pypdf.PdfReader(file_path)
        text = ""
        for page in reader.pages:
            text += page.extract_text() or ""
        return text
    elif ext == '.txt':
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    else:
        raise ValueError(f"Unsupported file format: {ext}")

def compute_mean_pooling(model_output, attention_mask):
    token_embeddings = model_output[0]
    input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)

def embed_texts(texts):
    tokenizer, model = get_embedding_model()
    encoded_input = tokenizer(texts, padding=True, truncation=True, return_tensors='pt')
    with torch.no_grad():
        model_output = model(**encoded_input)
    embeddings = compute_mean_pooling(model_output, encoded_input['attention_mask'])
    embeddings = torch.nn.functional.normalize(embeddings, p=2, dim=1)
    return embeddings.cpu().numpy()


# ----------------- LLM Generation Fallbacks -----------------

def query_groq(prompt, api_key):
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": "llama-3.1-8b-instant",
        "messages": [
            {"role": "system", "content": "You are a precise document assistant. Answer the user question based ONLY on the provided context. If you cannot find the answer, state that clearly."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.2
    }
    response = requests.post(url, json=payload, headers=headers)
    if response.status_code == 200:
        return response.json()['choices'][0]['message']['content']
    else:
        raise Exception(f"Groq API error: {response.text}")

def query_openai(prompt, api_key):
    url = "https://api.openai.com/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": "gpt-4o-mini",
        "messages": [
            {"role": "system", "content": "You are a precise document assistant. Answer the user question based ONLY on the provided context. If you cannot find the answer, state that clearly."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.2
    }
    response = requests.post(url, json=payload, headers=headers)
    if response.status_code == 200:
        return response.json()['choices'][0]['message']['content']
    else:
        raise Exception(f"OpenAI API error: {response.text}")

def query_gemini(prompt, api_key):
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={api_key}"
    headers = {
        "Content-Type": "application/json"
    }
    # Pre-pend system instructions to prompt
    formatted_prompt = f"System: Answer the question based ONLY on the provided context. If you cannot find the answer, say 'I cannot find the answer in the document.'\n\n{prompt}"
    payload = {
        "contents": [
            {
                "parts": [{"text": formatted_prompt}]
            }
        ]
    }
    response = requests.post(url, json=payload, headers=headers)
    if response.status_code == 200:
        try:
            return response.json()['candidates'][0]['content']['parts'][0]['text']
        except KeyError:
            raise Exception("Gemini response format error or block")
    else:
        raise Exception(f"Gemini API error: {response.text}")

def query_local(context, question):
    tokenizer, model = get_local_llm()
    prompt = (
        f"Answer the following question based on the provided context. If not mentioned in the context, say 'I cannot find the answer'.\n"
        f"Context: {context}\n"
        f"Question: {question}\n"
        f"Answer:"
    )
    inputs = tokenizer(prompt, return_tensors='pt', truncation=True, max_length=512)
    with torch.no_grad():
        outputs = model.generate(**inputs, max_new_tokens=100, temperature=0.3)
    return tokenizer.decode(outputs[0], skip_special_tokens=True)


# ----------------- Flask Routes -----------------

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400

    chunk_size = int(request.form.get('chunk_size', 500))
    chunk_overlap = int(request.form.get('chunk_overlap', 100))

    try:
        # Save upload to a temp file
        temp_dir = tempfile.gettempdir()
        temp_path = os.path.join(temp_dir, file.filename)
        file.save(temp_path)

        # Ingest text
        text = extract_text_from_file(temp_path)
        os.remove(temp_path)

        # Split into chunks
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            length_function=len
        )
        chunks = splitter.split_text(text)

        if len(chunks) == 0:
            return jsonify({'error': 'Document contains no readable text.'}), 400

        # Embed and add
        embeddings = embed_texts(chunks)
        vector_store.add_documents(chunks, embeddings, file.filename)

        # Persist index
        with open(INDEX_PATH, 'wb') as f:
            pickle.dump(vector_store, f)

        return jsonify({
            'success': True,
            'message': f"Ingested {len(chunks)} chunks from '{file.filename}'",
            'total_chunks': len(vector_store.chunks)
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/query', methods=['POST'])
def query_index():
    data = request.json or {}
    question = data.get('question')
    top_k = int(data.get('top_k', 3))

    if not question:
        return jsonify({'error': 'Question is required'}), 400

    if len(vector_store.chunks) == 0:
        return jsonify({'error': 'No documents have been indexed yet. Please upload files first.'}), 400

    api_key = GROQ_API_KEY
    if not api_key:
        return jsonify({'error': 'GROQ_API_KEY environment variable is not set on the server. Please configure it in your Space Settings (Secrets).'}), 500

    try:
        # Embed query
        query_vector = embed_texts([question])[0]
        
        # Retrieval
        matches = vector_store.similarity_search(query_vector, k=top_k)
        
        # Combine context
        context = "\n\n".join([f"[Source: {m['filename']}] {m['chunk']}" for m in matches])
        prompt = f"Context:\n{context}\n\nQuestion: {question}"

        # Generate answer using Groq
        answer = query_groq(prompt, api_key)
        used_provider = "groq"

        return jsonify({
            'answer': answer,
            'provider': used_provider,
            'sources': matches
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/clear', methods=['POST'])
def clear_index():
    try:
        vector_store.clear()
        if os.path.exists(INDEX_PATH):
            os.remove(INDEX_PATH)
        return jsonify({'success': True, 'message': 'Vector store successfully cleared'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/status', methods=['GET'])
def get_status():
    return jsonify({
        'total_chunks': len(vector_store.chunks),
        'files': list(set(vector_store.filenames))
    })

if __name__ == '__main__':
    # Make sure static directory exist for templates
    os.makedirs(os.path.join(WORKSPACE_DIR, 'templates'), exist_ok=True)
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)
