---
title: QNA RAG
emoji: 🧠
colorFrom: blue
colorTo: indigo
sdk: docker
pinned: false
---

# GroundedRAG - Custom Document Q&A
A globally deployed Flask application for document Q&A and Retrieval-Augmented Generation (RAG).
